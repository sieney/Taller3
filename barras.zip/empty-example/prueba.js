// se llama una tabla con datos
let table;

// llamado a la imagen
let img;

// datos
let datoPriv;

let externo = 0;

//numero de filas en el archivo
let rowCount;

let row;

let valorOpcion;

// tamano
let tamano = 15;

//se crean botones

let btn1;
let btn2;
let btn3;
let btn4;
let btn5;
let btn6;
let btn7;
let btn8;
let btn9;

// canvas

let cnv;

// botones
let buttons;

// prueba

let ancho;

// colores del fondo
let fondo = 0;

function preload() {
    //carga el archivo y tiene en cuenta el titulo de las columnas
    table = loadTable("assets/promedioExterno.csv", "header");

}

// esta clase describe las propiedades de una sola partícula.

// una matriz para agregar múltiples partículas
let particles = [];

function setup() {
    
//    leftBuffer = createGraphics(400, 400);
//    rightBuffer = createGraphics(400, 400);

    rowCount = table.getRowCount();
    row = table.getRows();

    for (let i = 0; i < rowCount; i++) {
        const precio = row[i].getNum("precio");
    }
    
     // canvas

    fill('rgba(200,169,169,0.5)');

    cnv = createCanvas(900, 2200);
    cnv.position(150, 100);   

    //se crean 3 botones
    
    btn1 = createButton('1989');
    btn2 = createButton('1993');
    btn3 = createButton('1997');
    btn4 = createButton('2001');
    btn5 = createButton('2005');
    btn6 = createButton('2009');
    btn7 = createButton('2013');
    btn8 = createButton('2017');
    btn9 = createButton('2019');

    //se determina la función de cada botón cuado se oprime

    btn1.mousePressed(btnPressed1);
    btn2.mousePressed(btnPressed2);
    btn3.mousePressed(btnPressed3);
    btn4.mousePressed(btnPressed4);
    btn5.mousePressed(btnPressed5);
    btn6.mousePressed(btnPressed6);
    btn7.mousePressed(btnPressed7);
    btn8.mousePressed(btnPressed8);
    btn9.mousePressed(btnPressed9);

    //se crea un elemento que agrupa todos los botones
    buttons = selectAll('button');
    //a los botones se les da caracteristicas
    for (let i = 0; i < buttons.length; i++) {
        //que tengan este tamano
        buttons[i].size(100, 50);
        //que se ubiquen de esta forma
        buttons[i].position(10, 60 * i + 100);
    }
}

//cuando se oprime el botón btn
function btnPressed1() {

    valorOpcion = 0;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }

    for (let i = 0; i < tamano; i++) {
        let p = new Particle();
        particles.push(p);
    }
    
    console.log(tamano);
}

//cuando se oprime el botón 2nd btn
function btnPressed2() {

    valorOpcion = 1;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
    
    for (let i = 0; i < tamano; i++) {
        let p = new Particle2();
        particles.push(p);
    }
}

//cuando se oprime el botón 3rd btn
function btnPressed3() {
    //escriba en la consola 

    valorOpcion = 2;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
   2
    for (let i = 0; i < tamano; i++) {
        let p = new Particle3();
        particles.push(p);
    }
}

function btnPressed4() {
    //escriba en la consola 

    valorOpcion = 3;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
    
    for (let i = 0; i < tamano; i++) {
        let p = new Particle4();
        particles.push(p);
    }
}

function btnPressed5() {
    //escriba en la consola 
    valorOpcion = 4;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
    
    for (let i = 0; i < tamano; i++) {
        let p = new Particle5();
        particles.push(p);
    }
}

function btnPressed6() {
    //escriba en la consola 
    valorOpcion = 5;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
    
    for (let i = 0; i < tamano; i++) {
        let p = new Particle6();
        particles.push(p);
    }
}

function btnPressed7() {
    //escriba en la consola 
    valorOpcion = 6;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
    
    for (let i = 0; i < tamano; i++) {
        let p = new Particle7();
        particles.push(p);
    }
}

function btnPressed8() {
    //escriba en la consola 
    valorOpcion = 7;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
    
    for (let i = 0; i < tamano; i++) {
        let p = new Particle8();
        particles.push(p);
    }
}

function btnPressed9() {
    //escriba en la consola 
    valorOpcion = 8;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
    tamano = map(externo, 63, 209, 5, 50);
    console.log(tamano);
    
    for (let i = 0; i < particles.length; i++) {
        if (particles.length > 0) {
            particles.splice(i, 1);
        }
    }
    
    for (let i = 0; i < tamano; i++) {
        let p = new Particle9();
        particles.push(p);
    }
}

function draw() {
    background(fondo);

    for (let i = 0; i < particles.length; i++) {
        particles[i].createParticle();
        particles[i].moveParticle();
        particles[i].joinParticles(particles.slice(i));
    }

    text(datoPriv, 400, 35)
    textSize(30);
    fill('#5b4c1e');

}