// se llama una tabla con datos
let table;

//numero de filas en el archivo
let rowCount;

//variable de checkbox
let checkbox;
//variable que muestra el circulo cuando el checkbox esta activo
let mostrarCirculo = false;

//se crean 3 botones
let btn1;
let btn2;
let btn3;
let btn4;
let btn5;
let btn6;

//se crea el elemento h2
let textoH2;

// botones
let buttons;

//variable de slider
let slider;
//variable que guarda el valor del slider
let valorSlider;

//variable de radio button
let radio;

//variable que guarda el valor de radio button escogido
let valorRadioBtn;

// colores del fondo
let fondo = 0;

let escala = (1, 15);

let texto1 = true;
let texto2 = false;
let texto3 = false;
let texto4 = false;
let texto5 = false;
let texto6 = false;

function preload() {
    //carga el archivo y tiene en cuenta el titulo de las columnas
    //  table = loadTable("assets/precioInterno.csv", "header");
}

// esta clase describe las propiedades de una sola partícula.

class Particle {
    // establecer las coordenadas, el radio y la velocidad de una partícula en ambos ejes de coordenadas.
    constructor() {
        this.x = random(0, width);
        this.y = random(0, height);
        this.r = random(escala);
        this.xSpeed = random(-2, 2);
        this.ySpeed = random(-1, 1.5);
    }

    // creación de una partícula.
    createParticle() {
        noStroke();
        rect(this.x, this.y, this.r);
    }

    // poner la partícula en movimiento.
    moveParticle() {
        if (this.x < 0 || this.x > width)
            this.xSpeed *= -1;
        if (this.y < 0 || this.y > height)
            this.ySpeed *= -1;
        this.x += this.xSpeed;
        this.y += this.ySpeed;
    }

    // esta función crea las conexiones (líneas) entre partículas que están separadas menos de una cierta distancia
    joinParticles(paraticles) {
        particles.forEach(element => {
            let dis = dist(this.x, this.y, element.x, element.y);
            if (dis < 85) {
                stroke('rgba(255,255,255,0.2)');
                line(this.x, this.y, element.x, element.y);
            }
        });
    }
}

// una matriz para agregar múltiples partículas
let particles = [];

function setup() {

    fill('rgba(200,169,169,0.5)');
    createCanvas(720, 400);
    for (let i = 0; i < width / 10; i++) {
        particles.push(new Particle());


        //se crea el elemento h2
        textoH2 = createElement('h2', 'Link p5');

        textoH2.position(800, 500);

        createA('https://p5js.org/examples/simulate-particles.html');
        
        //rowCount = table.getRowCount();
        //
        //  //creamos un objeto que guarda la información de las filas de la tabla
        //  const row = table.getRows();  
        //
        //  for (let i = 0; i < rowCount; i++) 
        //  {
        //    //guardamos la información de la fila "tiempo" en una constante
        //    const x = row[i].getNum("tiempo");
        //    
        //    //guardamos la información de la fila "preciosInterno" en una constante
        //    const name = row[i].getString("preciosInternos");
        //    //Adiciono al arreglo un objeto de tipo Bubble, donde inicializo el objeto creando la Burbuja
        //    bubbles.push(new Bubble(tiempo, preciosInternos));
        //  }
    }

    //variable de radio button, el valor seleccionado por el usuario lo lee directamente en draw usando radio.value()
    radio = createRadio();
    radio.option('blue');
    radio.option('red');
    radio.option('white');
    radio.position(650, 550);
    radio.style('width', '60px');

    //variable de checkbox 
    checkbox = createCheckbox(' fondo'); //palabra al lado del checkbox
    checkbox.position(760, 570);
    //cuando se selecciona una opción llama a la funcion changeFill
    checkbox.changed(changeFill);

    //se crean 3 botones
    btn1 = createButton('2013');
    btn2 = createButton('2014');
    btn3 = createButton('2015');
    btn4 = createButton('2016');
    btn5 = createButton('2017');
    btn6 = createButton('2018');

    //se determina la función de cada botón cuado se oprime

    btn1.mousePressed(btnPressed1);
    btn2.mousePressed(btnPressed2);
    btn3.mousePressed(btnPressed3);
    btn4.mousePressed(btnPressed4);
    btn5.mousePressed(btnPressed5);
    btn6.mousePressed(btnPressed6);

    //se crea un elemento que agrupa todos los botones
    buttons = selectAll('button');
    //a los botones se les da caracteristicas
    for (let i = 0; i < buttons.length; i++) {
        //que tengan este tamaño
        buttons[i].size(100, 100);
        //que se ubiquen de esta forma
        buttons[i].position(100 * i, 560);
    }
}

//esta función lee la opción seleccionada por el usuario de los botones desplegables

//esta función se ejecuta cuando el checkbox es oprimida
function changeFill() {
    //si el boton esta activo
    if (checkbox.checked()) {
        //coloque la variable mostrarCirculo en true
        mostrarCirculo = true;
    }
    //si el boton esta desactivado 
    else {
        //coloque la variable mostrarCirculo en false
        mostrarCirculo = false;
    }
}

//cuando se oprime el botón btn
function btnPressed1() {
    //escriba en la consola 
    texto1 = true;
    texto2 = false;
    texto3 = false;
    texto4 = false;
    texto5 = false;
    texto6 = false;
}

//cuando se oprime el botón 2nd btn
function btnPressed2() {
    //escriba en la consola 
    texto1 = false;
    texto2 = true;
    texto3 = false;
    texto4 = false;
    texto5 = false;
    texto6 = false;
}

//cuando se oprime el botón 3rd btn
function btnPressed3() {
    //escriba en la consola 
    texto1 = false;
    texto2 = false;
    texto3 = true;
    texto4 = false;
    texto5 = false;
    texto6 = false;
}

function btnPressed4() {
    //escriba en la consola 
    texto1 = false;
    texto2 = false;
    texto3 = false;
    texto4 = true;
    texto5 = false;
    texto6 = false;
}

function btnPressed5() {
    //escriba en la consola 
    texto1 = false;
    texto2 = false;
    texto3 = false;
    texto4 = false;
    texto5 = true;
    texto6 = false;
}

function btnPressed6() {
    //escriba en la consola 
    texto1 = false;
    texto2 = false;
    texto3 = false;
    texto4 = false;
    texto5 = false;
    texto6 = true;
}

function draw() {
    background(fondo);
    for (let i = 0; i < particles.length; i++) {
        particles[i].createParticle();
        particles[i].moveParticle();
        particles[i].joinParticles(particles.slice(i));
    }

    if (texto1 == true) {
        text("2013 - 466734", 10, 50);
        fill(128);
        textSize(30);
    }

    if (texto2 == true) {
        text("2014 - 702634", 10, 50);
        fill(128);
        textSize(30);
    }

    if (texto3 == true) {
        text("2015 - 716423", 10, 50);
        fill(128);
        textSize(30);
    }

    if (texto4 == true) {
        text("2016 - 829827", 10, 50);
        fill(128);
        textSize(30);
    }

    if (texto5 == true) {
        text("2017 - 818148", 10, 50);
        fill(128);
        textSize(30);
    }

    if (texto6 == true) {
        text("2018 - 741105", 10, 50);
        fill(128);
        textSize(30);
    }

    //el valor seleccionado de los radio buttons lo lee directamente en draw y se guarda en la variable valorRadioBtn
    valorRadioBtn = radio.value();
    //el nombre del color seleccionado es el collor del relleno de las figuras y el texto
    fill(valorRadioBtn);

    if (mostrarCirculo == true) {
        //muestre un circulo
        fondo = ('#5b4c1e');
    }

    if (mostrarCirculo == false) {
        //muestre un circulo
        fondo = ('#000000');
    }
}
