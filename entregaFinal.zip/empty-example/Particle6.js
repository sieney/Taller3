class Particle6 {
    // establecer las coordenadas, el radio y la velocidad de una partícula en ambos ejes de coordenadas.

    constructor() {
        this.x = random(500, 800);
        this.y = random(900, 1200);
        this.r = tamano;
        this.xSpeed = random(-2, 2);
        this.ySpeed = random(-1, 1.5);
    }

    // creación de una partícula.
    createParticle() {
//        tamaño = map(externo,63,209,5,50);
        noStroke();
        circle(this.x, this.y, this.r);
    }

    // poner la partícula en movimiento.
    moveParticle() {
        if (this.x < 500 || this.x > 800)
            this.xSpeed *= -1;
        if (this.y < 900 || this.y > 1200)
            this.ySpeed *= -1;
        this.x += this.xSpeed;
        this.y += this.ySpeed;
    }

    // esta función crea las conexiones (líneas) entre partículas que están separadas menos de una cierta distancia
    joinParticles(paraticles) {
        
        particles.forEach(element => {
            let dis = dist(this.x, this.y, element.x, element.y);
            if (dis < 100) {
                stroke('rgba(255,255,255,0.2)');
                line(this.x, this.y, element.x, element.y);
            }
        });
    }
}