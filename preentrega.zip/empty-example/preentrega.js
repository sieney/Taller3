// se llama una tabla con datos
let table;

// llamado a la imagen
let img;

// datos

let datoPriv;

let externo = 0;

//numero de filas en el archivo
let rowCount;

let row;

let valorOpcion;

// tamaño
let tamaño = 15;

//let datoPrecio = 0;
//let tamaño2;

//se crean 3 botones

let btn1;
let btn2;
let btn3;
let btn4;
let btn5;
let btn6;
let btn7;
let btn8;
let btn9;

// botones
let buttons;

let cnv = false;

// colores del fondo
let fondo = 0;

function preload() {
    //carga el archivo y tiene en cuenta el titulo de las columnas
  table = loadTable("assets/promedioExterno.csv", "header");
    
}

// esta clase describe las propiedades de una sola partícula.

class Particle {
    // establecer las coordenadas, el radio y la velocidad de una partícula en ambos ejes de coordenadas.
//    tamaño = map(externo,63,209,0,200);
    constructor() {
        this.x = random(0, width);
        this.y = random(0, height);
        this.r = tamaño;
        this.xSpeed = random(-2, 2);
        this.ySpeed = random(-1, 1.5);
    }

    // creación de una partícula.
    createParticle() {
//        tamaño = map(externo,63,209,5,50);
        noStroke();
        circle(this.x, this.y, this.r);
    }

    // poner la partícula en movimiento.
    moveParticle() {
        if (this.x < 0 || this.x > width)
            this.xSpeed *= -1;
        if (this.y < 0 || this.y > height)
            this.ySpeed *= -1;
        this.x += this.xSpeed;
        this.y += this.ySpeed;
    }

    // esta función crea las conexiones (líneas) entre partículas que están separadas menos de una cierta distancia
    joinParticles(paraticles) {
        
        particles.forEach(element => {
            let dis = dist(this.x, this.y, element.x, element.y);
            if (dis < 100) {
                stroke('rgba(255,255,255,0.2)');
                line(this.x, this.y, element.x, element.y);
            }
        });
    }
}

// una matriz para agregar múltiples partículas
let particles = [];

function setup() {
    
    rowCount = table.getRowCount();
    row = table.getRows();
    
    for (let i = 0; i < rowCount; i++){
        const precio = row[i].getNum("precio");
//        datoPrecio = precio;
    }

    fill('rgba(200,169,169,0.5)');
    cnv = createCanvas(300, 300);
    cnv.position(200, 100);
    for (let i = 0; i < width / 10; i++) {
        particles.push(new Particle());
    }
    

    //se crean 3 botones
    btn1 = createButton('1989');
    btn2 = createButton('1993');
    btn3 = createButton('1997');
    btn4 = createButton('2001');
    btn5 = createButton('2005');
    btn6 = createButton('2009');
    btn7 = createButton('2013');
    btn8 = createButton('2017');
    btn9 = createButton('2019');

    //se determina la función de cada botón cuado se oprime

    btn1.mousePressed(btnPressed1);
    btn2.mousePressed(btnPressed2);
    btn3.mousePressed(btnPressed3);
    btn4.mousePressed(btnPressed4);
    btn5.mousePressed(btnPressed5);
    btn6.mousePressed(btnPressed6);
    btn7.mousePressed(btnPressed7);
    btn8.mousePressed(btnPressed8);
    btn9.mousePressed(btnPressed9);

    //se crea un elemento que agrupa todos los botones
    buttons = selectAll('button');
    //a los botones se les da caracteristicas
    for (let i = 0; i < buttons.length; i++) {
        //que tengan este tamaño
        buttons[i].size(100, 50);
        //que se ubiquen de esta forma
        buttons[i].position(10, 60 * i + 100);
    }
    
}

//cuando se oprime el botón btn
function btnPressed1() {
 valorOpcion = 0;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

//cuando se oprime el botón 2nd btn
function btnPressed2() {
  valorOpcion = 1;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

//cuando se oprime el botón 3rd btn
function btnPressed3() {
    //escriba en la consola 
    valorOpcion = 2;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

function btnPressed4() {
    //escriba en la consola 
    valorOpcion = 3;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

function btnPressed5() {
    //escriba en la consola 
    valorOpcion = 4;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

function btnPressed6() {
    //escriba en la consola 
    valorOpcion = 5;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

function btnPressed7() {
    //escriba en la consola 
    valorOpcion = 6;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

function btnPressed8() {
    //escriba en la consola 
    valorOpcion = 7;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

function btnPressed9() {
    //escriba en la consola 
    valorOpcion = 8;
    externo = row[valorOpcion].getNum("precio");
    datoPriv = externo;
tamaño = map(externo,63,209,5,50);
    console.log(tamaño);
}

function draw() {
    
    background(fondo);
    for (let i = 0; i < particles.length; i++) { 
        particles[i].createParticle();
        particles[i].moveParticle();
        particles[i].joinParticles(particles.slice(i));
    }

    text(datoPriv,100,100)
    textSize(30);
    fill ('#5b4c1e');
}